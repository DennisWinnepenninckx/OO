package ui;

import domain.Asiel;
import domain.Hond;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class FxApp {
    public static void main(String[] args) {
        try{
            Hond hond1 = new Hond("Alice",3.5,2014 );
            Hond hond2 = new Hond("Benji",1.7,2018 );
            Hond hond3 = new Hond("Carl",2.4,2017 );
            Hond hond4 = new Hond("Dolly",5.5,2016 );
            Hond hond5 = new Hond("Engel",4.7,2008 );
          //  Hond hond5 = new Hond("Engel",-5,2008 );
           // Hond hond6 = new Hond("Engel",5,1800 );
          //  Hond hond7 = new Hond("Engel",5,2800 );

            Asiel asiel = new Asiel("Naam");
            asiel.voegHondToe(hond1);
            asiel.voegHondToe(hond2);
            asiel.voegHondToe(hond3);
            asiel.voegHondToe(hond4);
            asiel.voegHondToe(hond5);
            System.out.println(asiel.geefAsielInfo(12.66));

        }catch(IllegalArgumentException e){
            System.out.print(e.getMessage());
        }
    }
}
