package domain;
public class Asiel {
    private String naam;
    private Hond hond1, hond2,hond3,hond4,hond5;

    public Asiel(String pnaam){
        if (pnaam == null){
            throw new IllegalArgumentException("Naam van het asiel mag niet leeg zijn");
        }
        naam = pnaam;
    }
    public boolean voegHondToe(Hond phond){
        if (hond1 == null){
            hond1 = phond;
            return true;
        }
        if (hond2 == null){
            hond2 = phond;
            return true;
        }
        if (hond3 == null){
            hond3 = phond;
            return true;
        }
        if (hond4 == null){
            hond4 = phond;
            return true;
        }
        if (hond5 == null){
            hond5 = phond;
            return true;
        }
        return false;
    }
    public double rekenenVoerPerWeek(){
        double totaal=0;
        if (hond1 != null){
            totaal = totaal + hond1.rekenenVoerPerDag();
        }
        if (hond2 != null){
            totaal = totaal + hond2.rekenenVoerPerDag();
        }
        if (hond3 != null){
            totaal = totaal + hond3.rekenenVoerPerDag();
        }
        if (hond4 != null){
            totaal = totaal + hond4.rekenenVoerPerDag();
        }
        if (hond5 != null){
            totaal = totaal + hond5.rekenenVoerPerDag();
        }
        return totaal * 7;
    }
    public double rekenenVoerKostenPerWeek(double pPrijs){
        if(pPrijs < 0){
            throw new IllegalArgumentException("De prijs van voedsel mag niet negatief zijn");
        }
        return pPrijs * rekenenVoerPerWeek();
    }
    public String geefAsielInfo(double pPrijs){
        String Tekst = "";
        if (hond1 != null){
            Tekst = hond1.geefHondInfo();
        }
        if (hond2 != null){
            Tekst = Tekst + "\n" + hond2.geefHondInfo();
        }
        if (hond3 != null){
            Tekst = Tekst + "\n" + hond3.geefHondInfo();
        }
        if (hond4 != null){
            Tekst = Tekst + "\n" + hond4.geefHondInfo();
        }
        if (hond5 != null) {
            Tekst = Tekst + "\n" + hond5.geefHondInfo();
        }
        Tekst = Tekst + "\n" + "Hondenvoer per week: " + rekenenVoerPerWeek() + " kg, Totale kosten: €" + (rekenenVoerKostenPerWeek(pPrijs));
        return Tekst;
    }
}
