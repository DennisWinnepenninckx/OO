package domain;

import java.time.LocalDate;

public class Hond {

    private String naam;
    private double gewicht;
    private int geboortejaar;

    public Hond(String pnaam, double pgewicht, int pjaar) {
        if (pnaam == null) {
            throw new IllegalArgumentException("De naam moet ingevuld zijn!");
        }
        if (pjaar < 1993 || pjaar > LocalDate.now().getYear()) {
            throw new IllegalArgumentException("Het jaar mag niet lager zijn dan 1993 en niet in de toekomst zijn!");
        }
        naam = pnaam;
        setGewicht(pgewicht);
        geboortejaar = pjaar;
    }

    public void setGewicht(double pgewicht) {
        if (pgewicht < 0) {
            throw new IllegalArgumentException("Gewicht moet positief zijn");
        }
        gewicht = pgewicht;
    }

    public int berekenLeeftijd() {
        return LocalDate.now().getYear() - geboortejaar;
    }

    public double rekenenVoerPerDag() {
        double kg = 0;
        kg = 0.15 + (0.12 * gewicht);
        if (berekenLeeftijd() < 2) {
            kg = kg * 2;
        }

        return kg;
    }

    public double rekenenAdoptieKosten() {
        if (berekenLeeftijd() < 2) {
            return 250.00;
        }
        if (berekenLeeftijd() <= 8) {
            return 150.00;
        }
        return 0.00;
    }

    public String geefHondInfo() {
        return "Naam: " + naam + ", Leeftijd: " + berekenLeeftijd() + " jaar, Gewicht: " + gewicht + " kg, Adoptiekost: €" + rekenenAdoptieKosten();
    }

    public String getNaam() {
        return naam;
    }

    public double getGewicht() {
        return gewicht;
    }

    public int getGeboortejaar() {
        return geboortejaar;
    }
}

